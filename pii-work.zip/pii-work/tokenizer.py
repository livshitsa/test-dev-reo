"""
PII Tokenization System
Supports: Delimited files (with/without headers), Fixed-length files, Nested XML files
Author: Data Migration Team
"""

import csv
import xml.etree.ElementTree as ET
import hmac
import hashlib
import os
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FileFormat(Enum):
    """Supported file formats"""
    DELIMITED_WITH_HEADER = "delimited_header"
    DELIMITED_NO_HEADER = "delimited_no_header"
    FIXED_LENGTH = "fixed_length"
    XML = "xml"


@dataclass
class FieldSpec:
    """Field specification for delimited and fixed-length files"""
    name: str
    field_type: Optional[str]  # SSN, NAME, EMAIL, etc. (None if not PII)
    is_pii: bool
    
    # For delimited files
    column_index: Optional[int] = None
    column_name: Optional[str] = None
    
    # For fixed-length files
    start_pos: Optional[int] = None
    end_pos: Optional[int] = None


@dataclass
class XMLFieldSpec:
    """Field specification for XML files"""
    name: str
    field_type: Optional[str]
    is_pii: bool
    xpath: str
    is_attribute: bool = False
    attribute_name: Optional[str] = None


class UniversalTokenizer:
    """
    Universal PII tokenization system supporting multiple file formats
    with collision-safe token generation and mapping file creation.
    """
    
    def __init__(self, secret_key: str):
        """
        Initialize tokenizer with secret key for HMAC
        
        Args:
            secret_key: Secret key for token generation (keep secure!)
        """
        self.secret_key = secret_key
        self.token_map = {}  # {short_token: {full_token, field_type, original_value}}
        self.reverse_map = {}  # {(field_type, original_value): short_token}
        self.short_token_counter = {}  # {field_type: counter}
        self.collision_check = {}  # {full_token: original_value}
        
        logger.info("Tokenizer initialized")
    
    def generate_full_token(self, value: str, field_type: str) -> str:
        """
        Generate full collision-safe token using HMAC-SHA256
        
        Args:
            value: Original PII value
            field_type: Type of PII (SSN, NAME, EMAIL, etc.)
            
        Returns:
            Full 256-bit collision-safe token
        """
        if not value or value.strip() == '':
            return value
        
        # Generate 256-bit HMAC-SHA256 hash
        token_bytes = hmac.new(
            self.secret_key.encode(),
            f"{field_type}:{value.strip()}".encode(),
            hashlib.sha256
        ).digest()
        
        full_token = f"{field_type}_{token_bytes.hex()}"
        
        # Collision detection
        if full_token in self.collision_check:
            if self.collision_check[full_token] != value.strip():
                raise ValueError(
                    f"COLLISION DETECTED! Token {full_token[:20]}... "
                    f"maps to different values"
                )
        else:
            self.collision_check[full_token] = value.strip()
        
        return full_token
    
    def get_short_token(self, value: str, field_type: str, 
                       max_width: Optional[int] = None) -> str:
        """
        Get or create short token for a value
        
        Args:
            value: Original PII value
            field_type: Type of PII
            max_width: Maximum width for fixed-length files
            
        Returns:
            Short token (mapped to full collision-safe token)
        """
        if not value or value.strip() == '':
            return value
        
        # Check if we already have a short token
        key = (field_type, value.strip())
        if key in self.reverse_map:
            return self.reverse_map[key]
        
        # Generate full token first (for mapping and collision detection)
        full_token = self.generate_full_token(value, field_type)
        
        # Initialize counter for this field type if needed
        if field_type not in self.short_token_counter:
            self.short_token_counter[field_type] = 0
        
        # Increment counter
        self.short_token_counter[field_type] += 1
        counter = self.short_token_counter[field_type]
        
        # Generate short token
        if max_width:
            # For fixed-length: must fit in width
            prefix_len = min(3, max_width - 7)
            prefix = field_type[:prefix_len].upper()
            counter_width = max_width - prefix_len
            short_token = f"{prefix}{counter:0{counter_width}d}"
            short_token = short_token[:max_width]
        else:
            # For delimited/XML: use readable format
            short_token = f"{field_type}_{counter:06d}"
        
        # Store mappings
        self.token_map[short_token] = {
            'full_token': full_token,
            'field_type': field_type,
            'original_value': value.strip()
        }
        self.reverse_map[key] = short_token
        
        return short_token
    
    def save_mapping(self, mapping_file: str):
        """
        Save token mapping to CSV file
        
        Args:
            mapping_file: Path to output mapping file
        """
        try:
            with open(mapping_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'short_token',
                    'full_collision_safe_token',
                    'field_type',
                    'note'
                ])
                for short_token, mapping in sorted(self.token_map.items()):
                    writer.writerow([
                        short_token,
                        mapping['full_token'],
                        mapping['field_type'],
                        'PII tokenized for comparison'
                    ])
            
            logger.info(f"Mapping saved to {mapping_file}")
            logger.info(f"Total unique PII values tokenized: {len(self.token_map)}")
            logger.info(f"Zero collisions detected ✓")
        except Exception as e:
            logger.error(f"Error saving mapping file: {e}")
            raise
    
    def load_mapping(self, mapping_file: str):
        """
        Load existing mapping (for consistency across runs)
        
        Args:
            mapping_file: Path to existing mapping file
        """
        try:
            with open(mapping_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    short_token = row['short_token']
                    self.token_map[short_token] = {
                        'full_token': row['full_collision_safe_token'],
                        'field_type': row['field_type']
                    }
            logger.info(f"Loaded {len(self.token_map)} tokens from {mapping_file}")
        except FileNotFoundError:
            logger.warning(f"Mapping file {mapping_file} not found, starting fresh")
        except Exception as e:
            logger.error(f"Error loading mapping file: {e}")
            raise
    
    # ==================== DELIMITED FILES ====================
    
    def process_delimited_file(self, input_file: str, output_file: str,
                               field_specs: List[FieldSpec],
                               delimiter: str = ',',
                               has_header: bool = True):
        """
        Process delimited file with or without header
        
        Args:
            input_file: Path to input file
            output_file: Path to output file
            field_specs: List of field specifications
            delimiter: Field delimiter
            has_header: Whether file has header row
        """
        logger.info(f"Processing delimited file: {input_file}")
        
        try:
            with open(input_file, 'r', encoding='utf-8') as infile, \
                 open(output_file, 'w', encoding='utf-8', newline='') as outfile:
                
                reader = csv.reader(infile, delimiter=delimiter)
                writer = csv.writer(outfile, delimiter=delimiter)
                
                # Handle header
                if has_header:
                    header = next(reader)
                    writer.writerow(header)
                    
                    # Build column mapping
                    column_map = {
                        spec.column_name: spec 
                        for spec in field_specs 
                        if spec.column_name
                    }
                else:
                    # Build index mapping
                    column_map = {
                        spec.column_index: spec 
                        for spec in field_specs 
                        if spec.column_index is not None
                    }
                
                # Process rows
                row_count = 0
                for row in reader:
                    tokenized_row = []
                    
                    for i, value in enumerate(row):
                        # Find field spec
                        if has_header:
                            field_name = header[i] if i < len(header) else None
                            spec = column_map.get(field_name)
                        else:
                            spec = column_map.get(i)
                        
                        # Tokenize if PII
                        if spec and spec.is_pii and spec.field_type:
                            tokenized_value = self.get_short_token(
                                value, spec.field_type
                            )
                        else:
                            tokenized_value = value
                        
                        tokenized_row.append(tokenized_value)
                    
                    writer.writerow(tokenized_row)
                    row_count += 1
                
                logger.info(f"Processed {row_count} rows from {input_file}")
        
        except Exception as e:
            logger.error(f"Error processing delimited file {input_file}: {e}")
            raise
    
    # ==================== FIXED-LENGTH FILES ====================
    
    def process_fixed_length_file(self, input_file: str, output_file: str,
                                  field_specs: List[FieldSpec]):
        """
        Process fixed-length file
        
        Args:
            input_file: Path to input file
            output_file: Path to output file
            field_specs: List of field specifications with start/end positions
        """
        logger.info(f"Processing fixed-length file: {input_file}")
        
        try:
            with open(input_file, 'r', encoding='utf-8') as infile, \
                 open(output_file, 'w', encoding='utf-8') as outfile:
                
                line_count = 0
                for line in infile:
                    if not line.strip():
                        outfile.write(line)
                        continue
                    
                    tokenized_line = ""
                    
                    for spec in field_specs:
                        # Extract value
                        value = line[spec.start_pos:spec.end_pos]
                        field_width = spec.end_pos - spec.start_pos
                        
                        # Tokenize if PII
                        if spec.is_pii and spec.field_type:
                            token = self.get_short_token(
                                value, spec.field_type, max_width=field_width
                            )
                            # Pad to maintain field width
                            tokenized_line += token.ljust(field_width)[:field_width]
                        else:
                            tokenized_line += value
                    
                    outfile.write(tokenized_line + '\n')
                    line_count += 1
                
                logger.info(f"Processed {line_count} lines from {input_file}")
        
        except Exception as e:
            logger.error(f"Error processing fixed-length file {input_file}: {e}")
            raise
    
    # ==================== XML FILES ====================
    
    def process_xml_file(self, input_file: str, output_file: str,
                        field_specs: List[XMLFieldSpec],
                        namespaces: Optional[Dict[str, str]] = None):
        """
        Process XML file with support for nested structures and XPath
        
        Args:
            input_file: Path to input XML file
            output_file: Path to output XML file
            field_specs: List of XML field specifications with XPath
            namespaces: Optional namespace mapping for XPath queries
        """
        logger.info(f"Processing XML file: {input_file}")
        
        try:
            tree = ET.parse(input_file)
            root = tree.getroot()
            
            # Extract namespaces if not provided
            if namespaces is None:
                namespaces = {}
                if root.tag.startswith('{'):
                    ns = root.tag[1:root.tag.index('}')]
                    namespaces['default'] = ns
            
            # Process each field spec
            elements_processed = 0
            for spec in field_specs:
                if not spec.is_pii or not spec.field_type:
                    continue
                
                try:
                    # Find all matching elements using XPath
                    if namespaces:
                        elements = root.findall(spec.xpath, namespaces)
                    else:
                        elements = root.findall(spec.xpath)
                    
                    # Tokenize each matching element
                    for element in elements:
                        if spec.is_attribute:
                            # Handle attribute
                            if spec.attribute_name and spec.attribute_name in element.attrib:
                                original = element.attrib[spec.attribute_name]
                                element.attrib[spec.attribute_name] = self.get_short_token(
                                    original, spec.field_type
                                )
                                elements_processed += 1
                        else:
                            # Handle element text
                            if element.text:
                                element.text = self.get_short_token(
                                    element.text, spec.field_type
                                )
                                elements_processed += 1
                
                except Exception as e:
                    logger.warning(f"XPath '{spec.xpath}' failed: {e}")
                    continue
            
            # Write output
            tree.write(output_file, encoding='utf-8', xml_declaration=True)
            logger.info(f"Processed {elements_processed} XML elements from {input_file}")
        
        except Exception as e:
            logger.error(f"Error processing XML file {input_file}: {e}")
            raise


class RecordMatcher:
    """
    Match records across files with different ordering
    """
    
    def __init__(self, tokenizer: UniversalTokenizer, key_fields: List[str]):
        """
        Initialize record matcher
        
        Args:
            tokenizer: UniversalTokenizer instance
            key_fields: Fields that uniquely identify a record
        """
        self.tokenizer = tokenizer
        self.key_fields = key_fields
        logger.info(f"RecordMatcher initialized with keys: {key_fields}")
    
    def create_record_key(self, record: Dict[str, str]) -> str:
        """Create composite key from key fields"""
        key_parts = [str(record.get(field, '')) for field in self.key_fields]
        return '||'.join(key_parts)
    
    def load_and_index_file(self, file_path: str, delimiter: str = ',') -> Dict[str, Dict[str, str]]:
        """
        Load file and index by composite key
        
        Args:
            file_path: Path to tokenized file
            delimiter: Field delimiter
            
        Returns:
            Dictionary indexed by composite key
        """
        indexed_records = {}
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f, delimiter=delimiter)
                
                for row in reader:
                    record_key = self.create_record_key(row)
                    indexed_records[record_key] = dict(row)
            
            logger.info(f"Indexed {len(indexed_records)} records from {file_path}")
        
        except Exception as e:
            logger.error(f"Error loading file {file_path}: {e}")
            raise
        
        return indexed_records
    
    def compare_files(self, legacy_file: str, new_file: str,
                     output_matched: str, output_legacy_only: str,
                     output_new_only: str, delimiter: str = ',') -> Dict[str, int]:
        """
        Compare two tokenized files and output matched/unmatched records
        
        Args:
            legacy_file: Path to legacy file
            new_file: Path to new file
            output_matched: Path to matched records output
            output_legacy_only: Path to legacy-only records output
            output_new_only: Path to new-only records output
            delimiter: Field delimiter
            
        Returns:
            Dictionary with match statistics
        """
        logger.info("Starting file comparison...")
        
        # Load and index both files
        legacy_records = self.load_and_index_file(legacy_file, delimiter)
        new_records = self.load_and_index_file(new_file, delimiter)
        
        # Find keys
        legacy_keys = set(legacy_records.keys())
        new_keys = set(new_records.keys())
        
        matched_keys = legacy_keys & new_keys
        legacy_only_keys = legacy_keys - new_keys
        new_only_keys = new_keys - legacy_keys
        
        logger.info(f"Matching Summary:")
        logger.info(f"  Matched records: {len(matched_keys)}")
        logger.info(f"  Legacy only: {len(legacy_only_keys)}")
        logger.info(f"  New only: {len(new_only_keys)}")
        
        # Write matched records (side-by-side comparison)
        if matched_keys:
            self._write_matched_records(
                matched_keys, legacy_records, new_records, output_matched
            )
        
        # Write legacy-only records
        self._write_unmatched(legacy_only_keys, legacy_records, output_legacy_only)
        
        # Write new-only records
        self._write_unmatched(new_only_keys, new_records, output_new_only)
        
        return {
            'matched': len(matched_keys),
            'legacy_only': len(legacy_only_keys),
            'new_only': len(new_only_keys)
        }
    
    def _write_matched_records(self, keys: Set[str], 
                               legacy_records: Dict, 
                               new_records: Dict,
                               output_file: str):
        """Write matched records with side-by-side comparison"""
        try:
            with open(output_file, 'w', encoding='utf-8', newline='') as f:
                sample_record = legacy_records[list(keys)[0]]
                legacy_fields = [f"legacy_{field}" for field in sample_record.keys()]
                new_fields = [f"new_{field}" for field in sample_record.keys()]
                all_fields = ['record_key'] + legacy_fields + new_fields + ['match_status']
                
                writer = csv.DictWriter(f, fieldnames=all_fields)
                writer.writeheader()
                
                for key in sorted(keys):
                    legacy_rec = legacy_records[key]
                    new_rec = new_records[key]
                    
                    # Check if values match
                    values_match = all(
                        legacy_rec.get(field) == new_rec.get(field)
                        for field in legacy_rec.keys()
                    )
                    
                    output_row = {'record_key': key}
                    output_row.update({f"legacy_{k}": v for k, v in legacy_rec.items()})
                    output_row.update({f"new_{k}": v for k, v in new_rec.items()})
                    output_row['match_status'] = 'MATCH' if values_match else 'MISMATCH'
                    
                    writer.writerow(output_row)
            
            logger.info(f"Matched records written to {output_file}")
        
        except Exception as e:
            logger.error(f"Error writing matched records: {e}")
            raise
    
    def _write_unmatched(self, keys: Set[str], 
                        records: Dict[str, Dict[str, str]], 
                        output_file: str):
        """Write unmatched records to file"""
        if not keys:
            logger.info(f"No unmatched records for {output_file}")
            return
        
        try:
            with open(output_file, 'w', encoding='utf-8', newline='') as f:
                sample_record = records[list(keys)[0]]
                writer = csv.DictWriter(
                    f, 
                    fieldnames=['record_key'] + list(sample_record.keys())
                )
                writer.writeheader()
                
                for key in sorted(keys):
                    output_row = {'record_key': key}
                    output_row.update(records[key])
                    writer.writerow(output_row)
            
            logger.info(f"Unmatched records written to {output_file}")
        
        except Exception as e:
            logger.error(f"Error writing unmatched records: {e}")
            raise