pii_tokenization/
├── requirements.txt
├── config.yaml (example)
├── tokenizer.py (main implementation)
├── run_tokenization.py (execution script)
└── README.md

