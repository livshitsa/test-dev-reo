"""
PII Tokenization Execution Script
Reads configuration and processes all files
"""

import yaml
import os
import sys
from tokenizer import (
    UniversalTokenizer, 
    RecordMatcher,
    FieldSpec, 
    XMLFieldSpec,
    logger
)


def load_config(config_file: str) -> dict:
    """Load YAML configuration"""
    try:
        with open(config_file, 'r') as f:
            config = yaml.safe_load(f)
        logger.info(f"Configuration loaded from {config_file}")
        return config
    except Exception as e:
        logger.error(f"Error loading configuration: {e}")
        sys.exit(1)


def parse_field_specs(specs_config: list) -> list:
    """Parse field specifications from config"""
    specs = []
    for spec in specs_config:
        specs.append(FieldSpec(
            name=spec['name'],
            field_type=spec.get('field_type'),
            is_pii=spec['is_pii'],
            column_index=spec.get('column_index'),
            column_name=spec.get('column_name'),
            start_pos=spec.get('start_pos'),
            end_pos=spec.get('end_pos')
        ))
    return specs


def parse_xml_field_specs(specs_config: list) -> list:
    """Parse XML field specifications from config"""
    specs = []
    for spec in specs_config:
        specs.append(XMLFieldSpec(
            name=spec['name'],
            field_type=spec.get('field_type'),
            is_pii=spec['is_pii'],
            xpath=spec['xpath'],
            is_attribute=spec.get('is_attribute', False),
            attribute_name=spec.get('attribute_name')
        ))
    return specs


def main(config_file: str = 'config.yaml'):
    """
    Main execution function
    
    Args:
        config_file: Path to YAML configuration file
    """
    # Load configuration
    config = load_config(config_file)
    
    # Get secret key (prefer environment variable)
    secret_key = os.environ.get('TOKENIZATION_KEY', config.get('secret_key'))
    if not secret_key or secret_key == 'your-secret-key-keep-this-secure':
        logger.warning("Using default secret key! Set TOKENIZATION_KEY environment variable in production!")
    
    # Initialize tokenizer
    tokenizer = UniversalTokenizer(secret_key=secret_key)
    
    # Create output directory if it doesn't exist
    os.makedirs('output', exist_ok=True)
    
    # Process delimited files
    if 'delimited_files' in config:
        logger.info("=" * 60)
        logger.info("PROCESSING DELIMITED FILES")
        logger.info("=" * 60)
        
        for file_config in config['delimited_files']:
            field_specs = parse_field_specs(file_config['field_specs'])
            
            tokenizer.process_delimited_file(
                input_file=file_config['input'],
                output_file=file_config['output'],
                field_specs=field_specs,
                delimiter=file_config.get('delimiter', ','),
                has_header=file_config.get('has_header', True)
            )
    
    # Process fixed-length files
    if 'fixed_length_files' in config:
        logger.info("=" * 60)
        logger.info("PROCESSING FIXED-LENGTH FILES")
        logger.info("=" * 60)
        
        for file_config in config['fixed_length_files']:
            field_specs = parse_field_specs(file_config['field_specs'])
            
            tokenizer.process_fixed_length_file(
                input_file=file_config['input'],
                output_file=file_config['output'],
                field_specs=field_specs
            )
    
    # Process XML files
    if 'xml_files' in config:
        logger.info("=" * 60)
        logger.info("PROCESSING XML FILES")
        logger.info("=" * 60)
        
        for file_config in config['xml_files']:
            field_specs = parse_xml_field_specs(file_config['field_specs'])
            
            tokenizer.process_xml_file(
                input_file=file_config['input'],
                output_file=file_config['output'],
                field_specs=field_specs,
                namespaces=file_config.get('namespaces')
            )
    
    # Save mapping file
    mapping_file = config.get('mapping_file', 'token_mapping.csv')
    tokenizer.save_mapping(mapping_file)
    
    # Perform record comparison if configured
    if config.get('comparison', {}).get('enabled', False):
        logger.info("=" * 60)
        logger.info("PERFORMING RECORD COMPARISON")
        logger.info("=" * 60)
        
        comp_config = config['comparison']
        key_fields = config.get('key_fields', [])
        
        if not key_fields:
            logger.warning("No key_fields specified, skipping comparison")
        else:
            matcher = RecordMatcher(tokenizer, key_fields)
            
            results = matcher.compare_files(
                legacy_file=comp_config['legacy_file'],
                new_file=comp_config['new_file'],
                output_matched=comp_config['output_matched'],
                output_legacy_only=comp_config['output_legacy_only'],
                output_new_only=comp_config['output_new_only'],
                delimiter=comp_config.get('delimiter', ',')
            )
            
            logger.info("Comparison complete!")
            logger.info(f"Results: {results}")
    
    logger.info("=" * 60)
    logger.info("TOKENIZATION COMPLETE!")
    logger.info("=" * 60)
    logger.info(f"Total unique PII values: {len(tokenizer.token_map)}")
    logger.info(f"Mapping file: {mapping_file}")
    logger.info("All files are ready for AI-based comparison!")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='PII Tokenization System')
    parser.add_argument(
        '--config',
        default='config.yaml',
        help='Path to configuration file (default: config.yaml)'
    )
    
    args = parser.parse_args()
    main(args.config)