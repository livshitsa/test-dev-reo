# PII Tokenization System

Production-ready system for tokenizing PII data across multiple file formats to enable safe AI-based comparison.

## Features

- ✅ **Collision-Safe**: 256-bit HMAC-SHA256 tokens with zero collision risk
- ✅ **Multi-Format**: Delimited (CSV/TSV), Fixed-Length, and Nested XML
- ✅ **Consistent Tokens**: Same PII value gets same token across all files
- ✅ **Record Matching**: Compare files with different record ordering
- ✅ **Mapping File**: Full traceability with token mapping
- ✅ **Configuration-Driven**: YAML-based configuration
- ✅ **Production-Ready**: Logging, error handling, validation

## Installation
```bash
pip install -r requirements.txt
```

## Quick Start

### 1. Set Secret Key (Recommended)
```bash
export TOKENIZATION_KEY="your-secure-secret-key-here"
```

### 2. Configure Your Files

Edit `config.yaml` to specify your input files and field mappings.

### 3. Run Tokenization
```bash
python run_tokenization.py --config config.yaml
```

### 4. Review Output

- Tokenized files in `output/` directory
- Token mapping in `token_mapping.csv`
- Comparison results (if enabled)

## Configuration

### Delimited Files
```yaml
delimited_files:
  - input: "data/customers.csv"
    output: "output/customers_tokenized.csv"
    delimiter: ","
    has_header: true
    field_specs:
      - name: "SSN"
        field_type: "SSN"
        is_pii: true
        column_name: "SSN"  # or column_index: 0 for no header
```

### Fixed-Length Files
```yaml
fixed_length_files:
  - input: "data/accounts.dat"
    output: "output/accounts_tokenized.dat"
    field_specs:
      - name: "SSN"
        field_type: "SSN"
        is_pii: true
        start_pos: 0
        end_pos: 11
```

### XML Files
```yaml
xml_files:
  - input: "data/transactions.xml"
    output: "output/transactions_tokenized.xml"
    field_specs:
      - name: "customer_ssn"
        field_type: "SSN"
        is_pii: true
        xpath: ".//PersonalInfo/SSN"
```

## PII Field Types

The `field_type` parameter is a **user-defined string** that serves as a namespace for your PII fields. You can use any string value you want - there is no hardcoded validation.

### Purpose of field_type

1. **Collision Prevention**: Ensures the same value in different contexts gets different tokens
   - `SSN:123456789` → Different token than `ACCT:123456789`
2. **Token Readability**: Creates readable token prefixes
   - `SSN_000001`, `EMAIL_000002`, etc.

### Common Examples (Use Any You Want)

- `SSN` - Social Security Numbers
- `NAME` - Names (first, last, full)
- `EMAIL` - Email addresses
- `PHONE` - Phone numbers
- `ADDRESS` - Physical addresses
- `DOB` - Dates of birth
- `DL` - Driver's License
- `CC` - Credit Card numbers
- `PASSPORT` - Passport numbers
- `ACCOUNT` - Bank account numbers
- **Any custom string you define**

### Best Practices

1. **Use descriptive names**: `SSN` is clearer than `S`
2. **Be consistent**: Use the same field_type for the same PII across all files
3. **Avoid special characters**: Stick to alphanumeric and underscores
4. **Keep it short**: Especially for fixed-length files where space matters

### Example
```yaml
field_specs:
  # Standard types
  - name: "SSN"
    field_type: "SSN"
    is_pii: true
  
  # Custom types - completely valid!
  - name: "EmployeeID"
    field_type: "EMP_ID"
    is_pii: true
  
  - name: "MedicalRecordNumber"
    field_type: "MRN"
    is_pii: true
```

**Note**: The field_type can be ANY string - it's just a label used for organizing your tokens.

## Record Matching

To compare files with different record ordering:
```yaml
key_fields:
  - AccountID
  - TransactionDate

comparison:
  enabled: true
  legacy_file: "output/legacy_tokenized.csv"
  new_file: "output/new_tokenized.csv"
  output_matched: "output/matched.csv"
  output_legacy_only: "output/legacy_only.csv"
  output_new_only: "output/new_only.csv"
```

## Security Best Practices

1. **Store secret key securely** - Use environment variables or key vault
2. **Protect mapping file** - Contains full collision-safe tokens
3. **Limit access** - Tokenized files still contain business data
4. **Rotate keys** - Periodically regenerate tokens with new key

## Troubleshooting

### XPath not matching XML elements

Check namespaces in your XML file. If elements have namespace prefixes, specify in config:
```yaml
namespaces:
  ns: "http://example.com/namespace"

field_specs:
  - xpath: ".//ns:PersonalInfo/ns:SSN"
```

### Fixed-length tokens truncated

Short tokens are automatically sized to fit field width. Check mapping file for full collision-safe tokens.

### Records not matching in comparison

Verify `key_fields` match the field names in your tokenized files.

## License

Internal use only 
-------
# Install dependencies
pip install -r requirements.txt

# Set secret key (production)
export TOKENIZATION_KEY="your-very-secure-secret-key"

# Run tokenization
python run_tokenization.py --config config.yaml